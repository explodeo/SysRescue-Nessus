return {recents={}, window={[1]=1024,[2]=640,[3]=138,[4]=121,["n"]=4}, window_mode="normal", previous_find={}, previous_replace={}}
